import React, { Component } from 'react'
import Modal from "react-responsive-modal";
import './css/style.css'
import icon from './assets/logo-hover.png'

class Header extends Component {
    

    constructor(props) {
        super(props)

        this.state = {
            sign: false,
            login: false,
            phone:'',
            name:'',
            email:'',
            password:'',
            nameError:'',
            phoneError:'',
            emailError:'',
            passworderror:''

        }
         this.baseState=
         {
            phone:'',
            name:'',
            email:'',
            password:'',
            nameError:'',
            phoneError:'',
            emailError:'',
            passworderror:''
         }
       
    }

    onOpenModal = () => {
        this.setState({ sign: true });
    };

    onOpenModalLogin = () => {
        this.setState({ login: true });
    };

    onCloseModal = () => {
        this.setState(this.baseState)
        this.setState({ sign: false });
    };

    onCloseModalclose = () => {
        this.setState(this.baseState)
        this.setState({ login: false });
    };

   handleName=(e)=>{
       this.setState({name:e.target.value})
   }
   handleEmail=(e)=>{
    this.setState({email:e.target.value})
}
handlePassword=(e)=>{
    this.setState({password:e.target.value})
}
handlePhone=(e)=>{
    this.setState({phone:e.target.value})
}
validate =() =>{
    let nameError="";
    let phoneError="";
    let emailError="";
    let passworderror="";
    if(this.state.name==""){    
        nameError="Enter Name"
     }
     if(this.state.password==""){ 
        passworderror="Enter Password"
     }
     var phoneno = /^\d{10}$/;
     if(!this.state.phone.match(phoneno))
     {
         phoneError="Enter valid phoneNo"
     }
 
    if(!this.state.email.includes("@")){
        emailError="invalidEmail";
    }
   
    if(emailError || nameError || passworderror ||phoneError){
        this.setState({emailError,nameError,passworderror,phoneError});
        // this.setState(this.baseState);
    }
return true;
    
}
handlesubmit=(e)=>{
    e.preventDefault();
    const isValid=this.validate();
    if(isValid){
        alert("inprogre{ss")
        return true;
    }
}
handleLogin =(e)=>{
    console.log("login progress")
    //e.prevetDefault();
    const isValid=this.validate();
    if(isValid){
        alert("inprogre{ss")
        return true;
        
        
    }
     alert("inprogre{ss")
    

}
//     handlePhonenumber= (e)=>{
//         if(/^\d{10}$/.test(e.target.value)){
           
//             return true
//         }
//        else{
// alert("Please enter valid mobile number")
//        }
//     }
//     handlephoneChange =(e)=>{
        
//         this.setState({phone:e.target.value})
        
       
//     }
   
    // handleName =(e1) =>{
    //     if(e1.target.value == ""){
    //         alert("please enter Name")
    //     }
    // }


    render() {
        const { login, sign } = this.state;
        return (

            <>
                <header className="header header-animated opaque" style={{ "display": 'block', "paddingTop": "5px", "paddingBottom": "5px" }}>
                    <div className="container">
                        <nav className="navbar navbar-default" role="navigation">
                            <div className="navbar-header">
                                <a className="logo" href="#">
                                    <img className="img-responsive logo" src={icon} alt="" data-logo-alt={icon} />
                                </a>
                            </div>
                            {/* <div className="nav-toggle collapsed" data-toggle="collapse" data-target="#navbarMain" aria-expanded="false" style={{ "top": "15px" }}>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                            </div> */}
                            {/* <!-- Collect the nav links, forms, and other content for toggling --> */}
                            <div className="navbar-collapse collapse in" id="navbarMain" aria-expanded="true" style={{ top: "65px" }}>

                                <ul className="nav navbar-nav navbar-right">
                                    <li>
                                        <button className="btn btn-primary-outline" id="signup" onClick={this.onOpenModal}>SignUp</button>
                                    </li>
                                    <li>
                                        <button className="btn btn-primary-outline" id="login" onClick={this.onOpenModalLogin}>Login</button>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                </header>
                {/* Sign up model */}

                <Modal open={sign} onClose={this.onCloseModal}>
                    <div className="modal-body">
                        <h2>Get Started Absolutely<span> Free!</span></h2>
                        <span className="subtitle"></span>
                        <form className="contact-form form-validate3" novalidate="novalidate">
                            <div className="form-group">
                                <input className="form-control" type="text" name="name" id="name" value={this.state.name} placeholder="First Name" required="true" autocomplete="off" aria-required="true" onChange={(e) =>{this.handleName(e)}}/>
                            </div>
                        {this.state.nameError ?<div style={{fontSize:12,color:"red"}}>{this.state.nameError}</div>:null}
                            <div className="form-group">
                                <input className="form-control" type="phoneNumber" value={this.state.phone} name="phone" placeholder="Mobile-No"  autocomplete="off" aria-required="true" onChange={(e) =>{this.handlePhone(e)}} />
                            </div>
                            {this.state.phoneError ?<div style={{fontSize:12,color:"red"}}>{this.state.phoneError}</div>:null}
                            <div className="form-group">
                                <input className="form-control" type="phoneNumber" value={this.state.email} name="email" placeholder="Email"  autocomplete="off" aria-required="true" onChange={(e) =>{this.handleEmail(e)}} />
                            </div>
                            {this.state.emailError ?<div style={{fontSize:12,color:"red"}}>{this.state.emailError}</div>:null}
                            <div className="form-group">
                                <input type="password" name="password" className="form-control" placeholder="Password" value={this.state.password} required="" autocomplete="off" aria-required="true" onChange={(e) =>{this.handlePassword(e)}} />
                            </div>
                            {this.state.passworderror ?<div style={{fontSize:12,color:"red"}}>{this.state.passworderror}</div>:null}
                            <input className="btn btn-md btn-primary btn-center" id="sign_up" type="button" value="Sign Up" onClick={(e) =>this.handlesubmit(e)} />
                        </form>
                    </div>
                </Modal>

                {/* <!-- signUp End -->
                  <!-- login --> */}

                <Modal open={login} onClose={this.onCloseModalclose}>
                
                    <div className="modal-body">
                        <h2>Login and Get <span>Started</span></h2>
                        <span className="subtitle">Just fill in the form below</span>
                        <form className="contact-form form-validate4" novalidate="novalidate">
                            <div className="form-group">
                                <input className="form-control" type="email" name="Email" value={this.state.email}  onChange={(e) =>{this.handleEmail(e)}}  placeholder="Email" required="" autocomplete="off" aria-required="true" />
                            </div>
                            {this.state.emailError ?<div style={{fontSize:12,color:"red"}}>{this.state.emailError}</div>:null}
                            <div className="form-group">
                                <input type="password" name="pass" className="form-control" value={this.state.password} placeholder="Password" required="" autocomplete="off" aria-required="true" onChange={(e)=>{this.handlePassword(e)}} />
                            </div>
                            {this.state.passworderror ?<div style={{fontSize:12,color:"red"}}>{this.state.passworderror}</div>:null}
                            <input className="btn btn-md btn-primary btn-center" id="login_btn" type="button" value="Login" onClick={(e) =>this.handleLogin(e)} />
                        </form>
                    </div>
                </Modal>
            </>

        );
    }
}
export default Header
